
import time
import serial
      
ser = serial.Serial(              
	port='/dev/RS232_conv',
	baudrate = 9600,
	parity=serial.PARITY_NONE,
	stopbits=serial.STOPBITS_ONE,
	bytesize=serial.EIGHTBITS,
	)
      
ser.write('atdt*21*123456789*987654321#\r')
time.sleep(30)

# 123456789 zielrufnummer
# 987654321 umzuleitende lokale nummer

